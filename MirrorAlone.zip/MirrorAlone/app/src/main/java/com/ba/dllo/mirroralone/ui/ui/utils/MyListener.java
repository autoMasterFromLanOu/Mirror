package com.ba.dllo.mirroralone.ui.ui.utils;

/**
 * Created by ${巴为焱} on 16/6/25.
 */
public interface MyListener {
    int MyListener();
}
